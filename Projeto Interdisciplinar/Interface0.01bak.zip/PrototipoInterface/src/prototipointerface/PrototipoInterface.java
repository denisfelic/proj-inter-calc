
package prototipointerface;

public class PrototipoInterface {
            
    public static void main(String[] args) {
        PrototipoInterface();

    }

    public  static void PrototipoInterface() {
        JanelaPrincipal janela = new JanelaPrincipal();
        janela.setVisible(true);
        
    }
    
  
    
}
